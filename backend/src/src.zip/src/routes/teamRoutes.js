import express from 'express';
import {
  getTeams,
  getTeamById,
  addMember,
  updateTeamPoints,
  resetAllTeams,
  getAuditLogs
} from '../controllers/teamController.js';
import { authenticateToken, requireAdmin } from '../middleware/authMiddleware.js';

const router = express.Router();

// ============================================================================
// PUBLIC & TEAM VIEW ROUTES
// ============================================================================
router.get('/', getTeams);
router.get('/:id', getTeamById);

// ============================================================================
// ADD TEAMMATE (Direct Entry: Registration Number + Name)
// ============================================================================
router.post('/:id/members', addMember);
router.post('/members', addMember);

// ============================================================================
// ADMIN / SOURCE COMPUTER ROUTES (Protected - Admin Role Required)
// ============================================================================
router.post('/admin/update', authenticateToken, requireAdmin, updateTeamPoints);
router.post('/admin/reset-all', authenticateToken, requireAdmin, resetAllTeams);
router.get('/admin/logs', authenticateToken, requireAdmin, getAuditLogs);

export default router;
