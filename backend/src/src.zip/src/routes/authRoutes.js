import express from 'express';
import {
  teamRegister,
  teamLogin,
  adminLogin,
  getProfile
} from '../controllers/authController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';

const router = express.Router();

// ============================================================================
// TEAM AUTHENTICATION (Passwordless)
// ============================================================================
router.post('/team/register', teamRegister);
router.post('/team/login', teamLogin);
router.post('/team/entry', teamLogin);

// Fallbacks for general signup/signin routes
router.post('/register', teamRegister);
router.post('/signup', teamRegister);
router.post('/login', teamLogin);
router.post('/signin', teamLogin);

// ============================================================================
// ADMIN AUTHENTICATION (Requires Username & Password)
// ============================================================================
router.post('/admin/login', adminLogin);

// ============================================================================
// PROTECTED PROFILE
// ============================================================================
router.get('/profile', authenticateToken, getProfile);

export default router;
