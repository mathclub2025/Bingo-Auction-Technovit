import {
  getAllTeamsList,
  findTeamById,
  findTeamByName,
  findMemberByRegNo,
  addTeammate,
  updateTeamData,
  insertScoreAuditLog,
  getScoreAuditLogs,
  resetAllTeamsToInitial
} from '../services/teamStore.js';
import { broadcastTeamUpdate, broadcastAllTeams, broadcastAlert } from '../services/socketService.js';

/**
 * GET /api/teams
 * View all teams with coins, numbers collected, and member rosters
 * Accessible to Teams (Read-Only) and Public
 */
export async function getTeams(req, res) {
  try {
    const teams = await getAllTeamsList();
    return res.json({
      success: true,
      teams
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}

/**
 * GET /api/teams/:id
 * Get single team status and members
 */
export async function getTeamById(req, res) {
  try {
    const { id } = req.params;
    const team = await findTeamById(id);
    if (!team) return res.status(404).json({ error: 'Team not found.' });

    return res.json({ success: true, team });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}

/**
 * POST /api/teams/:id/members (or /api/teams/members)
 * Add a teammate directly to team_members
 * Inputs: regNo, name
 */
export async function addMember(req, res) {
  try {
    const teamId = req.params.id || req.body.teamId || req.user?.id;
    const { regNo, name } = req.body;

    if (!teamId) {
      return res.status(400).json({ error: 'Team ID is required.' });
    }
    if (!regNo || !regNo.trim()) {
      return res.status(400).json({ error: 'Teammate Registration Number is required.' });
    }
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Teammate Name is required.' });
    }

    const team = await findTeamById(teamId);
    if (!team) {
      return res.status(404).json({ error: 'Team not found.' });
    }

    const trimmedRegNo = regNo.trim().toUpperCase();
    const trimmedName = name.trim();

    // Check if student is already in ANY team
    const existing = await findMemberByRegNo(trimmedRegNo);
    if (existing) {
      const teamLabel = existing.team?.team_name ? ` (team: ${existing.team.team_name})` : '';
      return res.status(400).json({
        error: `Student with Registration Number "${trimmedRegNo}" is already registered in a team${teamLabel}.`
      });
    }

    // Add teammate to database
    const newMember = await addTeammate({
      teamId: team.id,
      name: trimmedName,
      regNo: trimmedRegNo
    });

    const updatedTeam = await findTeamById(team.id);

    // Realtime broadcast of updated team roster
    broadcastTeamUpdate(updatedTeam, {
      type: 'member_added',
      member: newMember
    });

    const allTeams = await getAllTeamsList();
    broadcastAllTeams(allTeams);

    return res.status(201).json({
      success: true,
      message: `Successfully added ${trimmedName} (${trimmedRegNo}) to ${team.team_name}`,
      member: newMember,
      team: updatedTeam
    });
  } catch (err) {
    console.error('Add member error:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}

/**
 * POST /api/teams/admin/update
 * Admin / Source Computer Only: Updates team coins, bonus, and numbers collected
 */
export async function updateTeamPoints(req, res) {
  try {
    const {
      teamId,
      teamName,
      coinsDeducted = 0,
      isQuestionAnswered = false,
      answerStatus,
      bonusCoins = 0,
      bonusAdded = 0,
      numberObtained = null,
      numberWon = null
    } = req.body;

    let team = null;
    if (teamId) {
      team = await findTeamById(teamId);
    } else if (teamName) {
      team = await findTeamByName(teamName);
    }

    if (!team) {
      return res.status(404).json({ error: 'Target team not found. Please select a valid team.' });
    }

    const prevCoins = Number(team.coins) || 0;
    const deduction = Math.max(0, Number(coinsDeducted) || 0);

    // Normalize answer status
    const isYes = isQuestionAnswered === true ||
                  isQuestionAnswered === 'yes' ||
                  answerStatus === 'yes';

    const bonus = isYes ? Math.max(0, Number(bonusCoins || bonusAdded) || 0) : 0;
    const targetNumber = isYes ? (numberObtained !== null ? numberObtained : numberWon) : null;

    // Calculate new coins (never below 0)
    const newCoins = Math.max(0, prevCoins - deduction + bonus);

    // Update numbers collected if answered yes and number provided
    let updatedNumbers = Array.isArray(team.numbers_collected) ? [...team.numbers_collected] : [];
    let numberAdded = null;

    if (isYes && targetNumber !== null && targetNumber !== undefined && String(targetNumber).trim() !== '') {
      const numVal = isNaN(Number(targetNumber)) ? String(targetNumber).trim() : Number(targetNumber);
      if (!updatedNumbers.includes(numVal)) {
        updatedNumbers.push(numVal);
        numberAdded = numVal;
      }
    }

    // Update team in database
    const updatedTeam = await updateTeamData(team.id, {
      coins: newCoins,
      numbers_collected: updatedNumbers
    });

    // Log in score_audit_logs table
    const auditLog = await insertScoreAuditLog({
      teamId: team.id,
      adminId: req.user?.id || null,
      coinsDeducted: deduction,
      bonusAdded: bonus,
      numberWon: numberAdded,
      answerStatus: isYes ? 'yes' : 'no',
      previousCoins: prevCoins,
      newCoins: newCoins
    });

    // Realtime broadcast via Socket.io
    broadcastTeamUpdate(updatedTeam, {
      auditLog,
      deduction,
      bonus,
      numberAdded
    });

    const allTeams = await getAllTeamsList();
    broadcastAllTeams(allTeams);

    // Realtime alert
    broadcastAlert({
      type: isYes ? 'success' : 'deduction',
      teamName: team.team_name,
      message: isYes
        ? `🎉 ${team.team_name} answered correctly! Deducted: -${deduction.toLocaleString()} | Bonus: +${bonus.toLocaleString()}${numberAdded !== null ? ` | Number Won: #${numberAdded}` : ''}`
        : `⚠️ ${team.team_name} deducted -${deduction.toLocaleString()} coins.`,
      teamId: team.id
    });

    return res.json({
      success: true,
      message: `Successfully updated ${team.team_name}`,
      team: updatedTeam,
      auditLog
    });
  } catch (err) {
    console.error('Update team points error:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}

/**
 * POST /api/teams/admin/reset-all
 * Admin Only: Reset all teams back to 50,000 coins and 0 numbers
 */
export async function resetAllTeams(req, res) {
  try {
    const resetTeams = await resetAllTeamsToInitial();
    const allTeams = await getAllTeamsList();
    broadcastAllTeams(allTeams);

    return res.json({
      success: true,
      message: 'All teams successfully reset to initial 50,000 coins.',
      teams: resetTeams
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}

/**
 * GET /api/teams/admin/logs
 * Admin Only: View score audit logs
 */
export async function getAuditLogs(req, res) {
  try {
    const logs = await getScoreAuditLogs();
    return res.json({ success: true, logs });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
