import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import {
  findTeamByName,
  findTeamById,
  createTeam,
  getAllTeamsList,
  findAdminByUsername
} from '../services/teamStore.js';
import { broadcastAllTeams } from '../services/socketService.js';

const JWT_SECRET = process.env.JWT_SECRET || 'math_club_auction_secret_key_2026';

/**
 * POST /api/auth/team/register (or /api/auth/register)
 * Team Registration (No password needed)
 * Inputs: teamName, captainName, captainRegNo
 * Initial coins: 50,000 | numbers_collected: []
 */
export async function teamRegister(req, res) {
  try {
    const { teamName, captainName, captainRegNo } = req.body;

    if (!teamName || !teamName.trim()) {
      return res.status(400).json({ error: 'Team Name is required.' });
    }
    if (!captainName || !captainName.trim()) {
      return res.status(400).json({ error: 'Captain Name is required.' });
    }
    if (!captainRegNo || !captainRegNo.trim()) {
      return res.status(400).json({ error: 'Captain Registration Number is required.' });
    }

    const trimmedTeam = teamName.trim();
    const trimmedCaptain = captainName.trim();
    const trimmedRegNo = captainRegNo.trim().toUpperCase();

    // Check if team name already exists
    const existing = await findTeamByName(trimmedTeam);
    if (existing) {
      return res.status(400).json({
        error: `A team with the name "${trimmedTeam}" is already registered. Please enter your team name under "Continue to Team Entry".`
      });
    }

    // Create team and insert captain into team_members
    const newTeam = await createTeam({
      teamName: trimmedTeam,
      captainName: trimmedCaptain,
      captainRegNo: trimmedRegNo
    });

    // Generate JWT token
    const token = jwt.sign(
      { id: newTeam.id, teamName: newTeam.team_name, role: 'team' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Broadcast updated team list to all connected clients
    const allTeams = await getAllTeamsList();
    broadcastAllTeams(allTeams);

    return res.status(201).json({
      message: 'Team registered successfully',
      token,
      team: newTeam
    });
  } catch (err) {
    console.error('Team register error:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}

/**
 * POST /api/auth/team/login (or /api/auth/team/entry or /api/auth/login)
 * Passwordless Team Login / Access Dashboard
 * Inputs: teamName
 */
export async function teamLogin(req, res) {
  try {
    const { teamName } = req.body;

    if (!teamName || !teamName.trim()) {
      return res.status(400).json({ error: 'Team Name is required to access the dashboard.' });
    }

    const trimmed = teamName.trim();
    const team = await findTeamByName(trimmed);

    if (!team) {
      return res.status(404).json({
        error: `No registered team found with name "${trimmed}". Please check the spelling or create a new team under "Register Team".`
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: team.id, teamName: team.team_name, role: 'team' },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({
      message: 'Team access granted',
      token,
      team
    });
  } catch (err) {
    console.error('Team login error:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}

/**
 * POST /api/auth/admin/login
 * Admin Sign In with Password Verification (bcrypt)
 * Inputs: username, password
 */
export async function adminLogin(req, res) {
  try {
    const { username, password } = req.body;

    if (!username || !username.trim()) {
      return res.status(400).json({ error: 'Admin username is required.' });
    }
    if (!password) {
      return res.status(400).json({ error: 'Admin password is required.' });
    }

    const admin = await findAdminByUsername(username.trim());
    if (!admin) {
      // If default admin is attempting login and DB is empty
      if (username.trim().toLowerCase() === 'admin' && password === 'admin123') {
        const token = jwt.sign(
          { id: '00000000-0000-0000-0000-000000000001', username: 'admin', role: 'admin', displayName: 'Admin Host' },
          JWT_SECRET,
          { expiresIn: '7d' }
        );
        return res.json({
          message: 'Admin authentication successful',
          token,
          admin: { id: '00000000-0000-0000-0000-000000000001', username: 'admin', display_name: 'Admin Host', role: 'admin' }
        });
      }
      return res.status(401).json({ error: 'Invalid admin credentials.' });
    }

    let isMatch = await bcrypt.compare(password, admin.password_hash);
    
    // Master fallback for default credentials
    if (!isMatch && username.trim().toLowerCase() === 'admin' && password === 'admin123') {
      isMatch = true;
    }

    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid admin credentials.' });
    }

    const token = jwt.sign(
      { id: admin.id, username: admin.username, role: 'admin', displayName: admin.display_name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { password_hash, ...safeAdmin } = admin;

    return res.json({
      message: 'Admin authentication successful',
      token,
      admin: safeAdmin
    });
  } catch (err) {
    console.error('Admin login error:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}

/**
 * GET /api/auth/profile
 * Get authenticated user profile via JWT
 */
export async function getProfile(req, res) {
  try {
    if (req.user.role === 'admin') {
      const admin = await findAdminByUsername(req.user.username);
      if (admin) {
        const { password_hash, ...safeAdmin } = admin;
        return res.json({ role: 'admin', user: safeAdmin });
      }
      return res.json({ role: 'admin', user: req.user });
    }

    const team = await findTeamById(req.user.id);
    if (!team) {
      return res.json({ role: 'team', team: req.user });
    }
    return res.json({ role: 'team', team });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
