import { pool } from '../config/db.js';

/**
 * Find Admin by Username
 */
export async function findAdminByUsername(username) {
  const trimmed = (username || '').trim();
  const res = await pool.query('SELECT * FROM public.admin_users WHERE username ILIKE $1 LIMIT 1', [trimmed]);
  return res.rows[0] || null;
}

/**
 * Find Team by Name (case-insensitive) with its members
 */
export async function findTeamByName(teamName) {
  const trimmed = (teamName || '').trim();
  const res = await pool.query('SELECT * FROM public.teams WHERE team_name ILIKE $1 LIMIT 1', [trimmed]);
  if (res.rows.length === 0) return null;
  const team = res.rows[0];
  
  const memRes = await pool.query('SELECT * FROM public.team_members WHERE team_id = $1', [team.id]);
  team.members = memRes.rows;
  return team;
}

/**
 * Find Team by ID with its members
 */
export async function findTeamById(id) {
  const res = await pool.query('SELECT * FROM public.teams WHERE id = $1 LIMIT 1', [id]);
  if (res.rows.length === 0) return null;
  const team = res.rows[0];
  
  const memRes = await pool.query('SELECT * FROM public.team_members WHERE team_id = $1', [team.id]);
  team.members = memRes.rows;
  return team;
}

/**
 * Check if a student Registration Number is already in any team
 */
export async function findMemberByRegNo(regNo) {
  const trimmed = (regNo || '').trim().toUpperCase();
  const res = await pool.query(`
    SELECT m.*, t.team_name as "team_name"
    FROM public.team_members m
    LEFT JOIN public.teams t ON m.team_id = t.id
    WHERE m.reg_no ILIKE $1 LIMIT 1
  `, [trimmed]);
  
  if (res.rows.length === 0) return null;
  const row = res.rows[0];
  // format it to match previous code
  return {
    ...row,
    team: { team_name: row.team_name }
  };
}

/**
 * Create a new team (No password) and add captain to team_members
 */
export async function createTeam({ teamName, captainName, captainRegNo }) {
  const trimmedTeam = teamName.trim();
  const trimmedCaptain = captainName.trim();
  const trimmedRegNo = captainRegNo.trim().toUpperCase();
  
  // Use a transaction
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    
    const teamRes = await client.query(
      'INSERT INTO public.teams (team_name, captain_name, captain_reg_no, coins, numbers_collected) VALUES ($1, $2, $3, 50000, $4::jsonb) RETURNING *',
      [trimmedTeam, trimmedCaptain, trimmedRegNo, JSON.stringify([])]
    );
    const team = teamRes.rows[0];
    
    const memRes = await client.query(
      'INSERT INTO public.team_members (team_id, name, reg_no, role) VALUES ($1, $2, $3, $4) RETURNING *',
      [team.id, trimmedCaptain, trimmedRegNo, 'Captain']
    );
    const member = memRes.rows[0];
    
    await client.query('COMMIT');
    team.members = [member];
    return team;
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

/**
 * Add a Teammate directly into team_members
 */
export async function addTeammate({ teamId, name, regNo }) {
  const trimmedName = name.trim();
  const trimmedRegNo = regNo.trim().toUpperCase();
  
  const res = await pool.query(
    'INSERT INTO public.team_members (team_id, name, reg_no, role) VALUES ($1, $2, $3, $4) RETURNING *',
    [teamId, trimmedName, trimmedRegNo, 'Teammate']
  );
  return res.rows[0];
}

/**
 * Get all teams ordered by coins descending, including members
 */
export async function getAllTeamsList() {
  // Fetch all teams
  const teamRes = await pool.query('SELECT * FROM public.teams ORDER BY coins DESC');
  const teams = teamRes.rows;
  
  if (teams.length === 0) return [];
  
  // Fetch all members
  const memRes = await pool.query('SELECT * FROM public.team_members');
  const members = memRes.rows;
  
  // Group members by team_id
  for (const team of teams) {
    team.members = members.filter(m => m.team_id === team.id);
  }
  
  return teams;
}

/**
 * Update team data in DB
 */
export async function updateTeamData(id, updatePayload) {
  let query = 'UPDATE public.teams SET updated_at = NOW()';
  const values = [];
  let index = 1;
  
  if (updatePayload.coins !== undefined) {
    query += `, coins = $${index}`;
    values.push(updatePayload.coins);
    index++;
  }
  
  if (updatePayload.numbers_collected !== undefined) {
    query += `, numbers_collected = $${index}::jsonb`;
    values.push(JSON.stringify(updatePayload.numbers_collected));
    index++;
  }
  
  query += ` WHERE id = $${index} RETURNING *`;
  values.push(id);
  
  const res = await pool.query(query, values);
  if (res.rows.length === 0) return null;
  
  const team = res.rows[0];
  const memRes = await pool.query('SELECT * FROM public.team_members WHERE team_id = $1', [team.id]);
  team.members = memRes.rows;
  return team;
}

/**
 * Insert into score_audit_logs
 */
export async function insertScoreAuditLog({ teamId, adminId, coinsDeducted, bonusAdded, numberWon, answerStatus, previousCoins, newCoins }) {
  const res = await pool.query(
    `INSERT INTO public.score_audit_logs 
      (team_id, admin_id, coins_deducted, bonus_added, number_won, answer_status, previous_coins, new_coins)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
     [teamId, adminId || null, coinsDeducted, bonusAdded || 0, numberWon || null, answerStatus, previousCoins, newCoins]
  );
  return res.rows[0];
}

/**
 * Get recent score audit logs
 */
export async function getScoreAuditLogs() {
  const res = await pool.query(`
    SELECT l.*, t.team_name as "team_name", a.username as "username", a.display_name as "display_name"
    FROM public.score_audit_logs l
    LEFT JOIN public.teams t ON l.team_id = t.id
    LEFT JOIN public.admin_users a ON l.admin_id = a.id
    ORDER BY l.created_at DESC
    LIMIT 50
  `);
  
  return res.rows.map(row => ({
    ...row,
    teams: { team_name: row.team_name },
    admin_users: { username: row.username, display_name: row.display_name }
  }));
}

/**
 * Reset all teams to initial 50,000 coins and empty numbers
 */
export async function resetAllTeamsToInitial() {
  const res = await pool.query(
    "UPDATE public.teams SET coins = 50000, numbers_collected = '[]'::jsonb RETURNING *"
  );
  const teams = res.rows;
  
  const memRes = await pool.query('SELECT * FROM public.team_members');
  const members = memRes.rows;
  
  for (const team of teams) {
    team.members = members.filter(m => m.team_id === team.id);
  }
  
  return teams;
}
