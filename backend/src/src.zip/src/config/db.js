import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

// Use the exact Postgres connection string provided
const connectionString = 'postgresql://postgres.lpeyccgizibzfcjdaigr:BingoMathsClub@aws-0-ap-south-1.pooler.supabase.com:5432/postgres';

export const pool = new Pool({
  connectionString,
  ssl: {
    rejectUnauthorized: false
  }
});

// Test connection
pool.connect((err, client, release) => {
  if (err) {
    return console.error('Error acquiring client', err.stack);
  }
  console.log('📦 [Database] Connected successfully to PostgreSQL via pg.');
  release();
});
